 <?php
    // $servername = "127.0.0.1";
    // $user = "root";
    // $password = "alawneh";
    // $dbname = "gym";

    $conn = mysqli_connect('localhost:3306', 'root', '', 'gym');
    return;
?>