<?php
    header("Location: /home/home-page.php")
    // header("Location: /test")
?>